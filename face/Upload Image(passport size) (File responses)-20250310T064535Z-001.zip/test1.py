import os
import pandas as pd

# Load the Excel file
excel_file = r"C:\Users\uk961\Downloads\Data Collection Form (Responses).xlsx"  df = pd.read_excel(excel_file)


image_folder = r"C:\Users\uk961\Downloads\Upload Image\Upload Image(passport size) (File responses)" 


for index, row in df.iterrows():
    old_name = row[2] 
    new_name = row[3]  
    
    old_path = os.path.join(image_folder, old_name)
    new_path = os.path.join(image_folder, f"{new_name}.jpg")     
   
    if os.path.exists(old_path):
        os.rename(old_path, new_path)
        print(f"Renamed: {old_name} → {new_name}.jpg")
    else:
        print(f"File not found: {old_name}")

print("Renaming complete!")
